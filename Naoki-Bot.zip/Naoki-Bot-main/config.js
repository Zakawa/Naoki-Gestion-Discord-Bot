module.exports = {
    app: {
        px: '+',
        token: '',
        owners: [""],
        funny: '',
        color: '#2f3136',
        footer: 'Protect',
        maxserver: '100',
        maxVol: '150',
        everyoneMention: false,
        hostedBy: true,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
}
